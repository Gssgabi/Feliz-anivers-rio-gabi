(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[37486],{

/***/ 559274:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var yzc=function(a,b){return{...b,files:b.files.map(c=>({...c,url:xzc(a,c.url)})),NU:b.NU?.map(c=>({...c,url:xzc(a,c.url)})),qnb:b.qnb?.map(c=>({...c,url:xzc(a,c.url)}))}},zzc=function(a,b){return{...b,fonts:b.fonts.map(c=>yzc(a,c))}},xzc=function(a,b){b=new URL(b);b.pathname=`/_framed/${encodeURIComponent(a.Oj.Ld)}${b.pathname}`;return b.toString()},Azc=__webpack_require__(929846)._;__c.Bzc=class{async QM(a){const b=Azc()();try{return b.r(await b.s(this.Pz.QM(a))).map(c=>zzc(this,c))}finally{b.s()}}Wv(a){return(a=this.Pz.Wv(a))&&zzc(this,a)}nK(a){return this.Pz.nK(a)}constructor(a,b){this.Oj=a;this.Pz=b}};__c.Czc=class{async RS(a){return this.Pk.RS(a)}mN(a,b){a=this.Pk.mN(a,b);if(a!=null)return b=new URL(a.url),b.pathname=`/_framed/${encodeURIComponent(this.Oj.Ld)}${b.pathname}`,{...a,url:b.toString()}}constructor(a,b){this.Oj=a;this.Pk=b}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/1a0114d389e72a2a.js.map