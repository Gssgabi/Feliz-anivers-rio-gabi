(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96793],{

/***/ 63272:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Syc;__c.lZ=function(a){Syc({...a,C:a.be})};Syc=function(a){const b={...a.props};a.C.sx(({Qk:c,lR:d})=>{c=a.bhc?{}:{He:c()};a.la.track(a.event,{...c,spanContext:d(),...b})})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/b5c14e920eafe8ec.js.map