(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[10354],{

/***/ 41109:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(22214);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.xGc={Ud:()=>({Yfc(a){return{data:{C:{VSa:{type:"uninitialized",F4:a.F4}},document:{}},L:{width:200,height:200}}},Qfc(a){return{data:{C:{VSa:{type:"initialized",WSa:a.WSa,M8a:`${"https://www.canvaqr.com"}/${a.WSa}`,sLa:a.sLa??{...__c.nG,color:"#000000"},Ona:a.Ona??{...__c.nG,color:"#ffffff"},bLa:a.bLa,F4:a.F4,EZ:a.EZ}},document:{}},L:{width:200,height:200}}}})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/472f49b5930e762a.js.map