(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97857],{

/***/ 494294:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(795488);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var N$c=function(a,b){b=a.Mg.get(__c.nv(b));return b!=null?a.H3.get(__c.nv(b.ref)):void 0},O$c=__webpack_require__(186901).fm;var P$c=({expr:a,resource:b,$H:c,Oc:d})=>{const e=O$c(()=>{__c.yza(c,b.ref.ref)});return{Pa:a.list(()=>{const f=N$c(c,b.ref.ref);if(!f)return[];__c.x(f.type==="group","Expected group element");const g=f.xs;if(d.ref&&g!=null){const h=new __c.iDc(a,new __c.gDc(d.ref),()=>g.dE);return f.Pa.filter(__c.Db).map(k=>h.create(k))}return f.Pa.filter(__c.Db).map(h=>__c.zH.create({...h,locked:!0,Uf:!0}))}),Xk:e}};__c.OJc={kk:__c.kA()(({Rz:{expr:a},Xf:{$H:b}})=>({...__c.oV,metadata:{type:"blueprint",gP:c=>c.co.resource.ref.id,name:__c.K("IqoIzw")},C:{type:0,Ks:({C:c})=>P$c({expr:a,resource:c.co.resource,$H:b,Oc:c.co.Oc})}}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/13aeed2b0d0b1c1c.js.map